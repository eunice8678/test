prompt --application/shared_components/security/authentications/garmin_passport
begin
--   Manifest
--     AUTHENTICATION: Garmin Passport
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>22996327915628055
,p_default_application_id=>180
,p_default_id_offset=>0
,p_default_owner=>'GARMIN'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(226340714714969295)
,p_name=>'Garmin Passport'
,p_scheme_type=>'NATIVE_CUSTOM'
,p_attribute_03=>'garmin.xx_asia_apex_pkg.garmin_passport_auth'
,p_attribute_05=>'N'
,p_invalid_session_type=>'LOGIN'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
,p_switch_in_session_yn=>'Y'
,p_reference_id=>23229364680767575
);
wwv_flow_imp.component_end;
end;
/
