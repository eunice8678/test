prompt --application/shared_components/security/authorizations/gisp_permission_control_without_control_value
begin
--   Manifest
--     SECURITY SCHEME: GISP Permission Control ( Without Control Value )
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>22996327915628055
,p_default_application_id=>180
,p_default_id_offset=>0
,p_default_owner=>'GARMIN'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(256539608987945463)
,p_name=>'GISP Permission Control ( Without Control Value )'
,p_scheme_type=>'NATIVE_FUNCTION_BODY'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Permission Control ( Without Control Value )',
'return garmin.xx_asia_apex_pkg.get_gisp_permission(',
'p_right => ''Coordinator'');'))
,p_error_message=>unistr('\7121\6B64\9801\9762\6B0A\9650')
,p_caching=>'NOCACHE'
);
wwv_flow_imp.component_end;
end;
/
