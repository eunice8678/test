prompt --application/shared_components/user_interface/templates/report/btravel
begin
--   Manifest
--     ROW TEMPLATE: BTRAVEL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>22996327915628055
,p_default_application_id=>180
,p_default_id_offset=>0
,p_default_owner=>'GARMIN'
);
wwv_flow_imp_shared.create_row_template(
 p_id=>wwv_flow_imp.id(226469080179416932)
,p_row_template_name=>'btravel'
,p_internal_name=>'BTRAVEL'
,p_row_template_before_rows=>' '
,p_row_template_after_rows=>' '
,p_row_template_type=>'GENERIC_COLUMNS'
,p_theme_id=>42
,p_theme_class_id=>7
,p_translate_this_template=>'N'
);
wwv_flow_imp.component_end;
end;
/
