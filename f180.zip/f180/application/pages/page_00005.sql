prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>22996327915628055
,p_default_application_id=>180
,p_default_id_offset=>0
,p_default_owner=>'GARMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>unistr('\51FA\5DEE\7533\8ACB\66A8\9810\652F\8ACB\6B3E\55AE')
,p_alias=>'REQUISITION'
,p_step_title=>unistr('\51FA\5DEE\7533\8ACB\66A8\9810\652F\8ACB\6B3E\55AE')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Form-fieldContainer {',
'    border-top: 1px solid #ccc; ',
'}',
'',
'.t-blue-content {',
'    color: rgb(37, 59, 158); ',
'    font-weight: bold; ',
'}',
'',
'.t-red-content {',
'    color: rgb(175, 44, 44); ',
'    font-weight: bold; ',
'}',
'',
unistr('#P5_\4E0A\8239\6E2C\8A66_LABEL {'),
'    color: rgb(134, 9, 9); ',
'    font-weight: bold; ',
'} ',
'',
'.t-Dialog-title {',
unistr('   text-align: center;  /* \6587\5B57\7F6E\4E2D */'),
unistr('     margin: 0 auto;    /*\81EA\52D5\6C34\5E73\5C45\4E2D */'),
' } ',
'',
'.t-Dialog-content {',
unistr('   text-align: left;  /* \6587\5B57\7F6E\4E2D */'),
unistr('     margin: 0 auto;    /*\81EA\52D5\6C34\5E73\5C45\4E2D */'),
' } ',
''))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(256539608987945463)
,p_browser_cache=>'Y'
,p_deep_linking=>'Y'
,p_page_component_map=>'13'
,p_last_updated_by=>'SHIHEUNICE@AD.GARMIN.COM'
,p_last_upd_yyyymmddhh24miss=>'20241224102555'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(226591152755754329)
,p_plug_name=>unistr('\51FA\5DEE\7533\8ACB\66A8\9810\652F\8ACB\6B3E\55AE')
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--accent15:t-Region--scrollBody:t-Form--slimPadding:margin-top-none:margin-bottom-none'
,p_plug_template=>wwv_flow_imp.id(226231794414982620)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'t-Dialog-title'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('    SELECT Distinct pm.GRID,sw.SWNAMC AS \8077\7B49,'),
'           DECODE(pm.STATUS,',
unistr('                  0, ''\7DE8\8F2F\4E2D'','),
unistr('                  1, ''\5DF2\9001\5448'','),
unistr('                  2, ''\7C3D\6838\4E2D'','),
unistr('                  3, ''\5DF2\6838\51C6'','),
unistr('                  4, ''\5DF2\9000\56DE'','),
unistr('                  5, ''\5DF2\522A\9664'','),
unistr('                  6, ''\5DF2\7D50\6848'','),
unistr('                  7, ''\62CB\8F49EB\4E2D'','),
unistr('                  8, ''8:\5DF2\7D50\6848'') AS \72C0\614B,'),
'           DECODE(pm.btravel_type,',
unistr('                  0, ''\570B\5167'','),
unistr('                  1, ''\570B\5916'','),
unistr('                  2, ''\53F0\7063'','),
'                  3, ''SEA+India'',',
'                  4, ''Out of SEA+India'',',
unistr('                  pm.btravel_type) AS \51FA\5DEE\985E\5225,'),
'',
unistr('           pm.DOC_NUM AS \8868\55AE\7DE8\865F,'),
unistr('           O.ORG_DESC AS \5EE0\5225,'),
unistr('           p.empid || ''-'' || p.enamc || '' ('' || p.ename || '') '' AS \7533\8ACB\4EBA,'),
'',
unistr('           dp.zdpnc AS \90E8\9580,'),
unistr('           ln.swnamc AS \7DDA\5225,'),
'',
'           pm.xx_eb_project_id AS EB_PROJECT,',
unistr('           pm.CONTACT_PHONE AS \9023\7D61\96FB\8A71,'),
unistr('           pm.SEE_ADDRESS AS \9001\6A5F\5730\5740,'),
unistr('           pm.MEET_ADDRESS AS \63A5\6A5F\5730\5740,'),
'',
unistr('           pm.MARINE_INSURANCE AS \4E0A\8239\6E2C\8A66,'),
unistr('           pm.MAP_NOTE || CHR(10) || pm.PRIVATE_DESCRIPTION AS \5099\8A3B'),
'',
'    FROM',
'        bpm.xx_btravel_prepaid_master pm,',
'        bpm.xx_btravel_prepaid_detail pd,',
'        garmin.xx_personal p,',
'        garmin.xx_swtype sw,',
'        garmin.xx_swtype ln,',
'        garmin.xx_pdp dp,',
'        bpm.xx_org_mapping O,',
'        garmin.xx_exchange_list el',
'    WHERE',
'        pm.grid = pd.master_grid',
'      AND p.empid = pm.applicant',
'      AND pm.ORG_ID = O.ORG_ID',
'      AND sw.lbgroup = 4',
'      AND ln.lbgroup = 7',
'      AND p.ejobd = sw.lbid',
'      AND p.edept = dp.zdept',
'      AND ln.lbid = pm.line_type_id',
'      AND el.empid = p.empid',
'      AND pm.grid = :P5_GRID',
'      '))
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_ajax_items_to_submit=>'P5_GRID'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_read_only_when_type=>'ALWAYS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(227855371899684708)
,p_plug_name=>'Detail'
,p_region_name=>'your_grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(226221945305982624)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  pm.grid,pd.grid as detail_grid,',
'        to_char(pd.start_date, ''yyyy/MM/DD'') as start_date,  ',
'        to_char(pd.end_date, ''yyyy/MM/DD'') as end_date,',
'      ',
'       pd.country_id || '':'' ||',
'       (select distinct country_name',
'          from bpm.xx_btravel_country',
'         where ou_id = pm.form_ouid',
'           and country_id = pd.country_id',
'           and region_id = pd.region_id) as departure_place,',
'    ',
'       pd.country_id_to || '':'' ||',
'       (select distinct country_name',
'          from bpm.xx_btravel_country',
'         where ou_id = pm.form_ouid',
'           and btravel_type = pm.btravel_type',
'           and country_id = pd.country_id_to',
'           and region_id = pd.region_id_to) as distination_place,     ',
'       replace(trim(pd.city), '','', ''.'') as city,',
'        to_char(pd.departure_date, ''yyyy/MM/DD'') as departure_date,',
'        to_char(pd.landing_date, ''yyyy/MM/DD'') as landing_date,',
'',
'       nvl((select distinct bt_fee_item_desc',
'             from bpm.xx_btravel_category_mapping',
'            where bt_fee_item_code = pd.ticket',
'              and ou_id = pm.FORM_OUID',
'              and type = ''T''),''N/A'') as ticket,',
'        pd.reason , pd.schedule,',
'        pd.ticket_amount,',
'        pd.ticket_emp_amount,',
'        pd.checkout_date',
'   ',
'from bpm.xx_btravel_prepaid_master pm,',
'     bpm.xx_btravel_prepaid_detail pd,',
'     garmin.xx_personal p,',
'     garmin.xx_swtype sw,',
'     garmin.xx_swtype ln,',
'     garmin.xx_pdp dp,',
'     bpm.xx_org_mapping O,',
'     garmin.xx_exchange_list el',
' where pm.grid = pd.master_grid',
'   and p.empid = pm.applicant',
'   and pm.ORG_ID = O.ORG_ID',
'   and sw.lbgroup = 4',
'   and ln.lbgroup = 7',
'   and p.ejobd = sw.lbid',
'   and p.edept = dp.zdept',
'   and ln.lbid = pm.line_type_id',
'   and el.empid = p.empid',
'   and pm.grid = :P5_GRID',
''))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P5_GRID'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Detail'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(228162384317060714)
,p_name=>'GRID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'GRID'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(228164022657060731)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(228165805840060749)
,p_name=>'START_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'START_DATE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>unistr('\958B\59CB\65E5\671F')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>130
,p_value_alignment=>'CENTER'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(228165914193060750)
,p_name=>'END_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'END_DATE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>unistr('\7D50\675F\65E5\671F')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>140
,p_value_alignment=>'CENTER'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(229712273838730602)
,p_name=>'CITY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CITY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>unistr('\57CE\5E02')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>220
,p_value_alignment=>'CENTER'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(229712313572730603)
,p_name=>'DEPARTURE_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DEPARTURE_DATE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>unistr('\53BB\7A0B\98DB\6A5F\62B5\9054\65E5\671F')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>170
,p_value_alignment=>'CENTER'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_format_mask=>'YYYY/MM/DD HH:MIPM'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(229712407661730604)
,p_name=>'LANDING_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LANDING_DATE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>unistr('\56DE\7A0B\98DB\6A5F\62B5\9054\65E5\671F')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>180
,p_value_alignment=>'CENTER'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_format_mask=>'YYYY/MM/DD HH:MIPM'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(229712578500730605)
,p_name=>'TICKET'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TICKET'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>unistr('\6A5F\7968')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>230
,p_value_alignment=>'CENTER'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(229712602296730606)
,p_name=>'REASON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'REASON'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>unistr('\51FA\5DEE\4E8B\7531')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>240
,p_value_alignment=>'CENTER'
,p_value_css_classes=>'custom-grid-column'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(229712737768730607)
,p_name=>'SCHEDULE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SCHEDULE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>unistr('\51FA\5DEE\884C\7A0B')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>250
,p_value_alignment=>'CENTER'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(229712877825730608)
,p_name=>'TICKET_AMOUNT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TICKET_AMOUNT'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('\6A5F\7968\91D1\984D')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>260
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(229712915411730609)
,p_name=>'TICKET_EMP_AMOUNT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TICKET_EMP_AMOUNT'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('\6A5F\7968\54E1\5DE5\8CA0\64D4\91D1\984D')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>270
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(229713024880730610)
,p_name=>'CHECKOUT_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CHECKOUT_DATE'
,p_data_type=>'DATE'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>unistr('\7D50\5E33\65E5\671F')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>280
,p_value_alignment=>'CENTER'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_format_mask=>'YYYY/MM/DD'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(229713119112730611)
,p_name=>'DEPARTURE_PLACE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DEPARTURE_PLACE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>unistr('\51FA\767C\5730')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>190
,p_value_alignment=>'CENTER'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(229713285085730612)
,p_name=>'DISTINATION_PLACE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DISTINATION_PLACE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>unistr('\76EE\7684\5730')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>200
,p_value_alignment=>'CENTER'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(239167553039708502)
,p_name=>'DETAIL_GRID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DETAIL_GRID'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(228162286114060713)
,p_internal_uid=>228162286114060713
,p_is_editable=>true
,p_edit_operations=>'u'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:RESET:SAVE'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(228188701975057686)
,p_interactive_grid_id=>wwv_flow_imp.id(228162286114060713)
,p_static_id=>'2281888'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(228188901397057686)
,p_report_id=>wwv_flow_imp.id(228188701975057686)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(62018390740992)
,p_view_id=>wwv_flow_imp.id(228188901397057686)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(228165805840060749)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>91.047
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(63477908740990)
,p_view_id=>wwv_flow_imp.id(228188901397057686)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(228165914193060750)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>86.9688
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(64796823740988)
,p_view_id=>wwv_flow_imp.id(228188901397057686)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(229712273838730602)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>78.969
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(66260799740987)
,p_view_id=>wwv_flow_imp.id(228188901397057686)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(229712313572730603)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>118.969
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(67581098740985)
,p_view_id=>wwv_flow_imp.id(228188901397057686)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(229712407661730604)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>125.969
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(69070861740983)
,p_view_id=>wwv_flow_imp.id(228188901397057686)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(229712578500730605)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>97.969
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(70460019740982)
,p_view_id=>wwv_flow_imp.id(228188901397057686)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(229712602296730606)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>167.9167
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(71871501740980)
,p_view_id=>wwv_flow_imp.id(228188901397057686)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(229712737768730607)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>586.021
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(73209479740978)
,p_view_id=>wwv_flow_imp.id(228188901397057686)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(229712877825730608)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>67.969
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(74669858740977)
,p_view_id=>wwv_flow_imp.id(228188901397057686)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(229712915411730609)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>124.969
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(76002071740974)
,p_view_id=>wwv_flow_imp.id(228188901397057686)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(229713024880730610)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>140.26600000000002
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(77438937740972)
,p_view_id=>wwv_flow_imp.id(228188901397057686)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(229713119112730611)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>118.969
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(78799408740971)
,p_view_id=>wwv_flow_imp.id(228188901397057686)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(229713285085730612)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>129.969
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(228189476558057685)
,p_view_id=>wwv_flow_imp.id(228188901397057686)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(228162384317060714)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(228211384962056502)
,p_view_id=>wwv_flow_imp.id(228188901397057686)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(228164022657060731)
,p_is_visible=>true
,p_is_frozen=>true
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(239431871942565762)
,p_view_id=>wwv_flow_imp.id(228188901397057686)
,p_display_seq=>16
,p_column_id=>wwv_flow_imp.id(239167553039708502)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(226579110258766920)
,p_name=>unistr('P5_\72C0\614B')
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_item_source_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_prompt=>unistr('\72C0\614B')
,p_source=>unistr('\72C0\614B')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(226301996636982591)
,p_item_css_classes=>'t-blue-content'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--normalDisplay'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(226579388880766922)
,p_name=>unistr('P5_\8868\55AE\7DE8\865F')
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_item_source_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_prompt=>unistr('\8868\55AE\7DE8\865F')
,p_source=>unistr('\8868\55AE\7DE8\865F')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(226301996636982591)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(226579524101766924)
,p_name=>unistr('P5_\5EE0\5225')
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_item_source_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_prompt=>unistr('\5EE0\5225')
,p_source=>unistr('\5EE0\5225')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_css_classes=>'.t-title-blue'
,p_field_template=>wwv_flow_imp.id(226301996636982591)
,p_item_css_classes=>'t-blue-content'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--normalDisplay'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(226579726835766926)
,p_name=>unistr('P5_\7533\8ACB\4EBA')
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_item_source_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_prompt=>unistr('\7533\8ACB\4EBA')
,p_source=>unistr('\7533\8ACB\4EBA')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(226301996636982591)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--normalDisplay'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(226579881572766927)
,p_name=>unistr('P5_\90E8\9580')
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_item_source_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_prompt=>unistr('\90E8\9580')
,p_source=>unistr('\90E8\9580')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(226301996636982591)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--normalDisplay'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(226579970378766928)
,p_name=>unistr('P5_\7DDA\5225')
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_item_source_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_prompt=>unistr('\7DDA\5225')
,p_source=>unistr('\7DDA\5225')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(226301996636982591)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--normalDisplay'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(226580123920766930)
,p_name=>unistr('P5_\9023\7D61\96FB\8A71')
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_item_source_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_prompt=>unistr('\9023\7D61\96FB\8A71')
,p_source=>unistr('\9023\7D61\96FB\8A71')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(226301996636982591)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--normalDisplay'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(226580255226766931)
,p_name=>unistr('P5_\9001\6A5F\5730\5740')
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_item_source_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_prompt=>unistr('\9001\6A5F\5730\5740')
,p_source=>unistr('\9001\6A5F\5730\5740')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(226301996636982591)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--normalDisplay'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(226580317016766932)
,p_name=>unistr('P5_\63A5\6A5F\5730\5740')
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>320
,p_item_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_item_source_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_prompt=>unistr('\63A5\6A5F\5730\5740')
,p_source=>unistr('\63A5\6A5F\5730\5740')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(226301996636982591)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--normalDisplay'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(226580461729766933)
,p_name=>unistr('P5_\4E0A\8239\6E2C\8A66')
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>330
,p_item_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_item_source_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_prompt=>unistr('\4E0A\8239\6E2C\8A66?')
,p_source=>unistr('\4E0A\8239\6E2C\8A66')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(226301996636982591)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--normalDisplay'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>22996327915628055
,p_default_application_id=>180
,p_default_id_offset=>0
,p_default_owner=>'GARMIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(226580884709766937)
,p_name=>unistr('P5_\8077\7B49')
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_item_source_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_prompt=>unistr('\8077\7B49')
,p_source=>unistr('\8077\7B49')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(226301996636982591)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--normalDisplay'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(226591534202754329)
,p_name=>'P5_GRID'
,p_source_data_type=>'VARCHAR2'
,p_is_primary_key=>true
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_item_source_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_source=>'GRID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(227922785760484602)
,p_name=>'P5_EB_PROJECT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_item_source_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_prompt=>'Eb Project'
,p_source=>'EB_PROJECT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(226301996636982591)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--normalDisplay'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(229714576983730625)
,p_name=>unistr('P5_\51FA\5DEE\985E\5225')
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_item_source_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_prompt=>unistr('\51FA\5DEE\985E\5225')
,p_source=>unistr('\51FA\5DEE\985E\5225')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(226301996636982591)
,p_item_css_classes=>'t-red-content'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(229714674705730626)
,p_name=>unistr('P5_\5099\8A3B')
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_item_source_plug_id=>wwv_flow_imp.id(226591152755754329)
,p_prompt=>unistr('\5099\8A3B')
,p_source=>unistr('\5099\8A3B')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(226301996636982591)
,p_item_css_classes=>'t-Dialog-content t-red-content'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--normalDisplay'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(228165407347060745)
,p_name=>'DA_Set Check Date'
,p_event_sequence=>30
,p_triggering_element_type=>'COLUMN'
,p_triggering_region_id=>wwv_flow_imp.id(227855371899684708)
,p_triggering_element=>'CHECKOUT_DATE'
,p_condition_element_type=>'COLUMN'
,p_condition_element=>'CHECKOUT_DATE'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(228165582299060746)
,p_event_id=>wwv_flow_imp.id(228165407347060745)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'COLUMN'
,p_affected_elements=>'CHECKOUT_DATE'
,p_attribute_01=>'PLSQL_EXPRESSION'
,p_attribute_04=>'to_char(sysdate,''YYYY/MM/DD'')'
,p_attribute_07=>'CHECKOUT_DATE'
,p_attribute_08=>'N'
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(229713337026730613)
,p_name=>'DA_Set Value'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(227855371899684708)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(229713474962730614)
,p_event_id=>wwv_flow_imp.id(229713337026730613)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'COLUMN'
,p_affected_elements=>'TICKET_AMOUNT'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'NULL'
,p_client_condition_elem_type=>'COLUMN'
,p_client_condition_element=>'TICKET_AMOUNT'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(239168978435708516)
,p_event_id=>wwv_flow_imp.id(229713337026730613)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'COLUMN'
,p_affected_elements=>'TICKET_EMP_AMOUNT'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'NULL'
,p_client_condition_elem_type=>'COLUMN'
,p_client_condition_element=>'TICKET_EMP_AMOUNT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(228164240279060733)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(227855371899684708)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'PS_Save Interactive Grid Data'
,p_attribute_01=>'PLSQL_CODE'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    CASE :APEX$ROW_STATUS',
'      --UPDATE',
'      WHEN ''U'' THEN',
'        UPDATE BPM.XX_BTRAVEL_PREPAID_DETAIL',
'        SET',
'            TICKET_AMOUNT = NVL(:TICKET_AMOUNT, 0) ,',
'            TICKET_EMP_AMOUNT =NVL(:TICKET_EMP_AMOUNT, 0),',
'            CHECKOUT_DATE = to_date(:CHECKOUT_DATE,''YYYY-MM-DD'')',
'        WHERE GRID = :detail_grid;',
'',
'    END CASE;',
'END;',
''))
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(226624431065754306)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(226591152755754329)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Master'
);
wwv_flow_imp.component_end;
end;
/
